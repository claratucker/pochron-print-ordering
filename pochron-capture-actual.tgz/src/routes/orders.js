import { Router } from 'express';
import { z } from 'zod';
import { db } from '../db/index.js';
import { config } from '../config.js';
import { loadCatalog } from '../lib/catalog.js';
import { suggestEmailFix, verifyEmail } from '../lib/emailcheck.js';
import { priceOrder, finalizeTotals, PriceError } from '../lib/pricing.js';
import { tax } from '../adapters/misc.js';
import { payment } from '../adapters/payment.js';
import { emails } from '../adapters/email.js';
import { newRef, getOrderByRef } from '../lib/orders.js';
import { readDraftToken } from '../lib/auth.js';

export const ordersRouter = Router();

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Turn a Stripe decline into a specific, customer-safe message. Card errors carry a
// decline_code (why the bank said no) and an already-friendly .message; anything
// else falls back to a generic line. Exported for testing.
export function cardErrorMessage(e) {
  const code = e.decline_code || e.code;
  const map = {
    insufficient_funds: 'Your card has insufficient funds. Please use a different card.',
    expired_card: 'Your card has expired. Please use a different card.',
    incorrect_cvc: "Your card's security code (CVC) doesn't match. Please re-enter it.",
    invalid_cvc: "Your card's security code (CVC) is invalid. Please re-enter it.",
    incorrect_number: 'Your card number is incorrect. Please check it and try again.',
    invalid_number: 'Your card number is invalid. Please check it and try again.',
    invalid_expiry_month: "Your card's expiration month is invalid.",
    invalid_expiry_year: "Your card's expiration year is invalid.",
    card_declined: 'Your card was declined. Please use a different card or contact your bank.',
    generic_decline: 'Your card was declined. Please use a different card or contact your bank.',
    processing_error: 'There was a problem processing your card. Please try again in a moment.',
  };
  if (code && map[code]) return map[code];
  if (e.type === 'StripeCardError' && e.message) return e.message;  // Stripe's message is customer-safe
  return 'Your card could not be authorized. Please try a different card.';
}

// Normalized self-edit recipe (from the browser editor, mapped in the client).
// passthrough() keeps any extra editor fields without failing validation; the
// server render only reads the known keys.
const RecipeSchema = z
  .object({
    crop: z
      .object({ left: z.number(), top: z.number(), width: z.number(), height: z.number() })
      .partial()
      .optional(),
    rotate: z.number().optional(),
    straighten: z.number().optional(),
    flipX: z.boolean().optional(),
    flipY: z.boolean().optional(),
    brightness: z.number().optional(),
    saturation: z.number().optional(),
    contrast: z.number().optional(),
    warmth: z.number().optional(),
  })
  .passthrough();

const ItemSchema = z.object({
  fileId: z.string(),
  paper: z.string(),
  size: z.string(),
  border: z.enum(['none', 'border']).default('none'),
  qty: z.number().int().positive().default(1),
  colorPath: z.enum(['none', 'studio', 'self']).default('none'),
  adjust: RecipeSchema.optional(),
  posX: z.number().optional(),
  posY: z.number().optional(),
});
const OrderSchema = z.object({
  items: z.array(ItemSchema).min(1),
  contact: z.object({
    name: z.string().min(1, 'your name'),
    email: z.string().min(1, 'your email'),
    phone: z.string().optional(),
  }),
  shipping: z.object({
    name: z.string().optional(),
    addr1: z.string().min(1, 'a street address'),
    addr2: z.string().optional(),
    city: z.string().min(1, 'city'),
    state: z.string().min(1, 'state'),
    zip: z.string().min(1, 'ZIP'),
    country: z.string().default('United States'),
    method: z.string(),
  }),
  whiteLabel: z.boolean().default(false),
  whiteLabelName: z.string().trim().min(1).max(120).optional(),
  whiteLabelReturn: z.object({
    addr1: z.string().optional(),
    addr2: z.string().optional(),
    city: z.string().optional(),
    state: z.string().optional(),
    zip: z.string().optional(),
    country: z.string().default('United States'),
  }).optional(),
  emailConfirmed: z.boolean().default(false),   // customer kept their address after a typo warning
  lowResAck: z.boolean().default(false),
  paymentMethodId: z.string().optional(),   // Stripe pm_... (production)
});

// POST /api/orders — place the order. Authorize now, capture on approval (§6/§9).
ordersRouter.post('/', async (req, res) => {
  const parsed = OrderSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Please complete the required fields.', details: parsed.error.flatten() });
  }
  const { items, contact, shipping, whiteLabel, whiteLabelName, whiteLabelReturn, lowResAck, emailConfirmed, paymentMethodId } = parsed.data;

  // Email format gate (layer 1 of §8; verification API + confirmation email are the stronger layers).
  if (!EMAIL_RE.test(contact.email)) {
    return res.status(400).json({ error: "That email address doesn't look right. Please double-check it.", field: 'email' });
  }

  // Layer 2 — typo suggestion. A wrong address is silent and costly, so a
  // near-miss on a common domain is surfaced once; the customer can confirm
  // their address is right and continue.
  if (!emailConfirmed) {
    const suggestion = suggestEmailFix(contact.email);
    if (suggestion) {
      return res.status(422).json({
        error: `Did you mean ${suggestion}?`,
        code: 'EMAIL_TYPO_SUSPECTED',
        field: 'email',
        suggestion,
      });
    }
  }

  // Layer 3 — mailbox verification. Only a confirmed-undeliverable address
  // blocks; 'unknown' (no provider configured, or a provider outage) never does.
  if (!emailConfirmed) {
    const verdict = await verifyEmail(contact.email);
    if (verdict === 'undeliverable') {
      return res.status(422).json({
        error: "We couldn't deliver mail to that address. Please check it — we send your order updates there.",
        code: 'EMAIL_UNDELIVERABLE',
        field: 'email',
      });
    }
  }

  // Load the real files + recompute the price SERVER-SIDE. The client total is never trusted.
  const fileIds = items.map((i) => i.fileId);
  const files = db.prepare(
    `SELECT * FROM files WHERE id IN (${fileIds.map(() => '?').join(',')})`
  ).all(...fileIds);
  const foundIds = new Set(files.map((f) => f.id));
  const missing = fileIds.filter((id) => !foundIds.has(id));
  if (missing.length) return res.status(409).json({ error: 'Some uploads are missing or not yet validated.', missing });

  // White-label parcels ship under the customer's own business name (§10), so
  // that name is required whenever the flag is set — there's nothing to print
  // on the label otherwise.
  if (whiteLabel) {
    const r = whiteLabelReturn || {};
    const missing = !(whiteLabelName && whiteLabelName.trim())
      || !(r.addr1 && r.addr1.trim()) || !(r.city && r.city.trim())
      || !(r.state && r.state.trim()) || !(r.zip && r.zip.trim());
    if (missing) {
      return res.status(422).json({
        error: 'For white-label packaging, give the sender name and return address to print on the parcel.',
        code: 'NEEDS_WHITE_LABEL_RETURN',
      });
    }
  }

  let quote;
  let taxResult = { amount: 0, status: 'none', provider: 'none' };
  try {
    const cat = loadCatalog();
    const q = priceOrder(cat, items, files, shipping.method, shipping);

    // Low-res acknowledgment gate — any too-small image requires explicit ack (§4).
    if (q.anyTooSmall && !lowResAck) {
      return res.status(422).json({
        error: 'Please confirm the low-resolution image(s) before submitting.',
        code: 'NEEDS_LOWRES_ACK',
      });
    }
    // 100+ prints → manual quote, not a self-serve charge (§7).
    if (q.manualQuote) {
      return res.status(422).json({
        error: 'Orders of 100+ prints are custom-quoted. Please contact the studio.',
        code: 'MANUAL_QUOTE', studio: config.email.studioContactUrl,
      });
    }
    if (q.shipGate) {
      return res.status(422).json({
        error: 'We don\'t ship to that destination through the site yet — please contact the studio for a shipping quote.',
        code: 'SHIP_QUOTE', studio: config.email.studioContactUrl,
      });
    }
    taxResult = await tax.quote({ printsTotal: q.printsTotal, shippingCost: q.shippingCost, address: shipping });
    quote = finalizeTotals(q, taxResult.amount);
  } catch (e) {
    if (e instanceof PriceError) return res.status(400).json({ error: e.message });
    throw e;
  }

  const ref = newRef();

  // Authorize payment (auth now, capture on approval).
  // A live payment processor needs an actual card. Without one the PaymentIntent
  // is created but never confirmed, so nothing is authorized — and accepting the
  // order anyway would show the customer a confirmation and put an unfunded job
  // in the studio queue. Refuse before creating anything.
  if (payment.name !== 'mock' && !paymentMethodId) {
    return res.status(402).json({
      error: 'Please enter your card details to place the order.',
      code: 'NO_PAYMENT_METHOD',
    });
  }

  let auth;
  try {
    auth = await payment.authorize({ amount: quote.total, email: contact.email, orderRef: ref, paymentMethodId });
  } catch (e) {
    return res.status(402).json({ error: cardErrorMessage(e), detail: e.message, code: e.decline_code || e.code || null });
  }

  // Only 'authorized' (funds held) or a pending 3D Secure challenge may proceed.
  const OK_STATES = ['authorized', 'requires_action', 'requires_confirmation'];
  if (!OK_STATES.includes(auth.status)) {
    return res.status(402).json({
      error: 'Your card was not authorized. Please check the details and try again.',
      code: 'NOT_AUTHORIZED',
      detail: auth.status,
    });
  }

  // A bank may require 3D Secure. The order is still created (below) so the
  // customer never loses their work; the browser finishes the challenge and
  // calls /api/orders/:ref/payment-status to confirm the authorization.
  const needsAction = auth.status === 'requires_action' || auth.status === 'requires_confirmation';

  // Persist order + items atomically, then map file metadata onto each line.
  const fileById = Object.fromEntries(files.map((f) => [f.id, f]));
  const tx = db.transaction(() => {
    const info = db.prepare(
      `INSERT INTO orders
        (ref,status,customer_name,email,phone,
         ship_name,ship_addr1,ship_addr2,ship_city,ship_state,ship_zip,ship_country,ship_method,
         white_label,white_label_name,wl_addr1,wl_addr2,wl_city,wl_state,wl_zip,wl_country,
         low_res_ack,subtotal,discount_rate,discount_amount,shipping_cost,tax,tax_status,total,
         payment_ref,payment_status)
       VALUES (?, 'submitted', ?,?,?, ?,?,?,?,?,?,?,?, ?,?,?,?,?,?,?,?, ?,?,?,?,?,?,?,?, ?,?)`
    ).run(
      ref, contact.name, contact.email, contact.phone || null,
      shipping.name || contact.name, shipping.addr1, shipping.addr2 || null,
      shipping.city, shipping.state, shipping.zip, shipping.country || 'United States', shipping.method,
      whiteLabel ? 1 : 0, whiteLabel ? (whiteLabelName || null) : null,
      whiteLabel ? (whiteLabelReturn?.addr1 || null) : null,
      whiteLabel ? (whiteLabelReturn?.addr2 || null) : null,
      whiteLabel ? (whiteLabelReturn?.city || null) : null,
      whiteLabel ? (whiteLabelReturn?.state || null) : null,
      whiteLabel ? (whiteLabelReturn?.zip || null) : null,
      whiteLabel ? (whiteLabelReturn?.country || 'United States') : null,
      lowResAck ? 1 : 0,
      quote.subtotal, quote.discountRate, quote.discountAmount, quote.shippingCost, quote.tax, taxResult.status, quote.total,
      auth.paymentRef, auth.status === 'authorized' || auth.status === 'requires_capture' ? 'authorized' : auth.status
    );
    const orderId = info.lastInsertRowid;

    const insItem = db.prepare(
      `INSERT INTO order_items
        (order_id,file_id,original_name,paper,size,border,qty,color_path,adjust_recipe,pos_x,pos_y,
         unit_price,cc_fee,line_total,width,height,dpi,dpi_flag)
       VALUES (?,?,?,?,?,?,?,?,?,?,?, ?,?,?,?,?,?,?)`
    );
    quote.lines.forEach((l, idx) => {
      const it = items[idx];
      const f = fileById[it.fileId];
      insItem.run(
        orderId, it.fileId, f.original_name, l.paper, l.size, l.border, l.qty, l.colorPath,
        // Store BOTH the edit recipe and the original ref for every photo (§6).
        it.colorPath === 'self' ? JSON.stringify(it.adjust || {}) : null,
        it.posX ?? 50, it.posY ?? 50,
        l.unitPrice, l.ccFee, l.lineTotal, l.width, l.height, l.dpi, l.dpiFlag
      );
    });

    db.prepare(`INSERT INTO order_events (order_id,from_status,to_status,note) VALUES (?,?, 'submitted', 'Order placed; payment authorized')`).run(orderId, 'draft');
    db.prepare(`UPDATE files SET order_id = ? WHERE id IN (${fileIds.map(() => '?').join(',')})`).run(orderId, ...fileIds);
    return orderId;
  });
  const orderId = tx();

  // Confirmation email — includes a copy of the submission; a bounce flags the order (§8/§11).
  const order = getOrderByRef(ref);
  try { await emails.confirmation(order); } catch (e) { console.error('Confirmation email failed:', e.message); }

  // Clear the guest draft now that it's submitted.
  const token = readDraftToken(req);
  if (token) db.prepare('DELETE FROM drafts WHERE token = ?').run(token);

  res.status(201).json({
    ref, orderId, status: 'submitted',
    total: quote.total, paymentStatus: 'authorized',
    message: 'Order received. We emailed a copy to ' + contact.email + '.',
    ...(needsAction ? { requiresAction: true, clientSecret: auth.clientSecret, code: 'REQUIRES_3DS' } : {}),
  });
});

// GET /api/orders/:ref?email=... — customer status lookup (guarded by email match).
ordersRouter.get('/:ref', (req, res) => {
  const order = getOrderByRef(req.params.ref);
  if (!order) return res.status(404).json({ error: 'Order not found.' });
  const email = (req.query.email || '').toString().toLowerCase();
  if (!email || email !== (order.email || '').toLowerCase()) {
    return res.status(403).json({ error: 'Provide the email on the order to view it.' });
  }
  res.json(publicView(order));
});

// POST /api/orders/:ref/payment-status — re-check the authorization after the
// customer completes a 3D Secure challenge in the browser, and record the
// result. Guarded by the order email like the status lookup.
ordersRouter.post('/:ref/payment-status', async (req, res) => {
  const order = getOrderByRef(req.params.ref);
  if (!order) return res.status(404).json({ error: 'Order not found.' });
  const email = String(req.body?.email || '').trim().toLowerCase();
  if (!email || email !== String(order.email).toLowerCase()) {
    return res.status(403).json({ error: 'Order lookup requires the email on the order.' });
  }
  if (!order.payment_ref) return res.status(409).json({ error: 'No payment on this order.' });
  try {
    const s = await payment.status({ paymentRef: order.payment_ref });
    const status = s.status === 'authorized' ? 'authorized' : s.status;
    db.prepare('UPDATE orders SET payment_status=? WHERE id=?').run(status, order.id);
    res.json({ ref: order.ref, paymentStatus: status, authorized: status === 'authorized' });
  } catch (e) {
    res.status(502).json({ error: 'Could not check the payment.', detail: e.message });
  }
});

// GET /api/orders/:ref/reauth — what the customer needs to re-confirm their
// card. Guarded by the order email like every other customer lookup.
ordersRouter.get('/:ref/reauth', async (req, res) => {
  const order = getOrderByRef(req.params.ref);
  if (!order) return res.status(404).json({ error: 'Order not found.' });
  const email = String(req.query.email || '').trim().toLowerCase();
  if (!email || email !== String(order.email).toLowerCase()) {
    return res.status(403).json({ error: 'Please use the link from your email.' });
  }
  if (['captured', 'partially_captured'].includes(order.payment_status)) {
    return res.json({ ref: order.ref, done: true, message: 'This order is already paid — nothing to do.' });
  }
  let clientSecret = null;
  try { clientSecret = (await payment.clientSecret({ paymentRef: order.payment_ref })) || null; } catch {}
  res.json({
    ref: order.ref,
    total: order.total,
    itemCount: order.items.length,
    paymentStatus: order.payment_status,
    clientSecret,
    publishableKey: config.payment.stripePublishable || null,
  });
});

// POST /api/orders/:ref/reauth-complete — called after the customer confirms in
// the browser. Re-reads the intent from the processor rather than trusting the
// client, then puts the order back in the studio queue.
ordersRouter.post('/:ref/reauth-complete', async (req, res) => {
  const order = getOrderByRef(req.params.ref);
  if (!order) return res.status(404).json({ error: 'Order not found.' });
  const email = String(req.body?.email || '').trim().toLowerCase();
  if (!email || email !== String(order.email).toLowerCase()) {
    return res.status(403).json({ error: 'Please use the link from your email.' });
  }
  try {
    const s = await payment.status({ paymentRef: order.payment_ref });
    if (s.status !== 'authorized') {
      return res.status(402).json({ error: 'That card was not authorized. Please try again.', code: 'NOT_AUTHORIZED', detail: s.status });
    }
    db.prepare(`UPDATE orders SET payment_status='authorized', authorized_at=datetime('now'), status='submitted' WHERE id=?`).run(order.id);
    db.prepare(`INSERT INTO order_messages (order_id,direction,body) VALUES (?, 'system', 'Customer re-confirmed their card; authorization renewed.')`).run(order.id);
    res.json({ ref: order.ref, authorized: true });
  } catch (e) {
    res.status(502).json({ error: 'Could not confirm the payment.', detail: e.message });
  }
});

function publicView(o) {
  return {
    ref: o.ref, status: o.status, total: o.total,
    items: o.items.map((i) => ({
      name: i.original_name, paper: i.paper, size: i.size, qty: i.qty,
      border: i.border, colorPath: i.color_path, lineTotal: i.line_total, status: i.item_status,
    })),
    tracking: o.tracking, createdAt: o.created_at,
    messages: o.messages.filter((m) => m.direction !== 'system').map((m) => ({ from: m.direction, body: m.body, at: m.created_at })),
  };
}
