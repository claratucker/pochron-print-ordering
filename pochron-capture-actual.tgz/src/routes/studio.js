import { Router } from 'express';
import { z } from 'zod';
import { db } from '../db/index.js';
import { config } from '../config.js';
import { authWindow, authLabel } from '../lib/authwindow.js';
import { requireStudio } from '../lib/auth.js';
import { payment } from '../adapters/payment.js';
import { emails } from '../adapters/email.js';
import { getOrder, transition, addMessage } from '../lib/orders.js';
import { captureAmountFor } from '../lib/pricing.js';
import { storage } from '../adapters/storage.js';
import { renderRecipe, recipeIsNoop } from '../lib/render.js';

// Render one self-edited item's recipe onto the full-res ORIGINAL and store the
// print-ready file. Returns { itemId, printUrl } or null when nothing to render
// (studio-corrected or as-submitted items print straight from the original).
async function renderPrintFile(item) {
  if (item.color_path !== 'self') return null;
  const recipe = item.adjust_recipe ? JSON.parse(item.adjust_recipe) : {};
  if (recipeIsNoop(recipe)) return null;
  const file = db.prepare('SELECT storage_key FROM files WHERE id=?').get(item.file_id);
  if (!file) return null;
  const original = await storage.getBuffer(file.storage_key);
  if (!original) return null;
  const outBuf = await renderRecipe(original, recipe, { format: 'tiff' });
  const key = `${item.file_id}/print/item-${item.id}.tiff`;
  await storage.writeDerived(key, outBuf);
  db.prepare('UPDATE order_items SET print_file_key=? WHERE id=?').run(key, item.id);
  return { itemId: item.id, printUrl: storage.publicUrl(key) };
}

// A signed, browser-loadable URL of the customer's edited version (recipe applied
// to the full-res original, downscaled for viewing). Served the same way originals
// are — a signed URL, NOT a header-auth'd endpoint — because it loads inside an
// <img> tag and opens in new tabs, neither of which can send the studio password.
// Rendered once and cached to R2; the recipe + original stay the source of truth.
async function editPreviewUrl(item) {
  if (item.color_path !== 'self') return null;
  const recipe = item.adjust_recipe ? JSON.parse(item.adjust_recipe) : {};
  if (recipeIsNoop(recipe)) return null;
  if (item.edit_preview_key) return storage.publicUrl(item.edit_preview_key);
  const file = db.prepare('SELECT storage_key FROM files WHERE id=?').get(item.file_id);
  if (!file) return null;
  try {
    const original = await storage.getBuffer(file.storage_key);
    if (!original) return null;
    const jpeg = await renderRecipe(original, recipe, { format: 'jpeg', maxDim: 1600 });
    const key = `${item.file_id}/edit/item-${item.id}.jpg`;
    await storage.writeDerived(key, jpeg, 'image/jpeg');
    db.prepare('UPDATE order_items SET edit_preview_key=? WHERE id=?').run(key, item.id);
    return storage.publicUrl(key);
  } catch (e) {
    console.error('Edit preview render failed:', e.message);
    return null;
  }
}

export const studioRouter = Router();
studioRouter.use(requireStudio);   // every studio route is authenticated

// GET /api/studio/queue — orders awaiting proof, plus recent history.
studioRouter.get('/queue', async (req, res) => {
  const rows = db.prepare(
    `SELECT id, ref, status, customer_name, email, phone,
            ship_name, ship_addr1, ship_addr2, ship_city, ship_state, ship_zip, ship_country,
            white_label, white_label_name, wl_addr1, wl_addr2, wl_city, wl_state, wl_zip, wl_country,
            tax_status, total, created_at,
            payment_ref, payment_status, authorized_at, reauth_count
       FROM orders ORDER BY (status IN ('submitted','on_hold')) DESC, created_at DESC LIMIT 100`
  ).all();
  const pending = rows.filter((o) => o.status === 'submitted' || o.status === 'on_hold').length;
  const queue = await Promise.all(rows.map(async (o) => {
    const full = getOrder(o.id);
    return {
      id: o.id, ref: o.ref, status: o.status, who: o.customer_name, email: o.email,
      phone: o.phone || null,
      // Where the prints actually go. This is what Julie ships to — distinct from
      // the return address printed on the parcel.
      shipTo: [
        o.ship_name || o.customer_name,
        o.ship_addr1,
        o.ship_addr2,
        [o.ship_city, o.ship_state].filter(Boolean).join(', ') + (o.ship_zip ? ' ' + o.ship_zip : ''),
        o.ship_country && !/^(us|usa|united states)$/i.test(String(o.ship_country).trim()) ? o.ship_country : null,
      ].filter((line) => line && line.trim()).join('\n'),
      whiteLabel: !!o.white_label, total: o.total, shippingCost: o.shipping_cost, createdAt: o.created_at,
      paymentStatus: o.payment_status || null,
      // The address that goes on the parcel: neutral for white-label (§10).
      whiteLabelName: o.white_label_name || null,
      taxStatus: o.tax_status || 'none',
      auth: (() => { const w = authWindow(o); return { ...w, label: authLabel(w) }; })(),
      taxNeedsReview: o.tax_status === 'failed',
      // White-label parcels ship under the CUSTOMER's own name + return address,
      // with no Pochron branding — this is what Julie prints as the sender.
      returnAddress: o.white_label
        ? [
            o.white_label_name || 'Sender',
            o.wl_addr1,
            o.wl_addr2,
            [o.wl_city, o.wl_state].filter(Boolean).join(', ') + (o.wl_zip ? ' ' + o.wl_zip : ''),
            o.wl_country && !/^(us|usa|united states)$/i.test(String(o.wl_country).trim()) ? o.wl_country : null,
          ].filter((line) => line && line.trim()).join('\n')
        : config.fulfillment.studioReturnAddress,
      items: await Promise.all(full.items.map(async (i) => ({
        id: i.id, name: i.original_name, paper: i.paper, size: i.size, qty: i.qty,
        border: i.border, colorPath: i.color_path,               // none | studio | self
        adjust: i.adjust_recipe ? JSON.parse(i.adjust_recipe) : null,
        px: i.width && i.height ? `${i.width}×${i.height}` : null,
        dpi: i.dpi, dpiFlag: i.dpi_flag, lineTotal: i.line_total,
        itemStatus: i.item_status,
        // Studio path prints from the ORIGINAL; self-edit stores recipe + original (§6).
        originalUrl: i.file_id ? storage.publicUrl(
          db.prepare('SELECT storage_key FROM files WHERE id=?').get(i.file_id)?.storage_key || ''
        ) : null,
        // The customer's edited version as a signed, browser-loadable URL (rendered
        // from recipe + original and cached), so Julie can SEE what will print.
        editedUrl: await editPreviewUrl(i),
      }))),
      messages: full.messages,
      // What the system emailed this customer, and whether it went out.
      emailLog: db.prepare(
        `SELECT type, recipient, status, error, created_at FROM email_log
          WHERE order_ref = ? ORDER BY created_at`
      ).all(o.ref),
    };
  }));
  res.json({ pending, total: rows.length, queue });
});

// GET /api/studio/orders.csv — a spreadsheet of all orders for Julie's records
// (accounting, taxes). Fetched with the studio header from the client, which then
// triggers the download, so it never needs a header-less navigation.
studioRouter.get('/orders.csv', (req, res) => {
  const orders = db.prepare('SELECT * FROM orders ORDER BY created_at DESC').all();
  const q = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const header = ['Ref', 'Date', 'Status', 'Payment', 'Customer', 'Email', 'Phone', 'Ship to',
    'White label', 'White-label name', 'Items', 'Subtotal', 'Shipping', 'Tax', 'Total'];
  const lines = [header.map(q).join(',')];
  for (const o of orders) {
    const items = db.prepare('SELECT paper, size, qty FROM order_items WHERE order_id = ?').all(o.id)
      .map((i) => `${i.paper} ${i.size} x${i.qty}`).join('; ');
    const shipTo = [
      o.ship_name || o.customer_name, o.ship_addr1, o.ship_addr2,
      [o.ship_city, o.ship_state].filter(Boolean).join(', ') + (o.ship_zip ? ' ' + o.ship_zip : ''),
      o.ship_country && !/^(us|usa|united states)$/i.test(String(o.ship_country).trim()) ? o.ship_country : null,
    ].filter((l) => l && String(l).trim()).join(', ');
    lines.push([o.ref, o.created_at, o.status, o.payment_status, o.customer_name, o.email, o.phone,
      shipTo, o.white_label ? 'Yes' : 'No', o.white_label_name, items,
      o.subtotal, o.shipping_cost, o.tax, o.total].map(q).join(','));
  }
  const csv = '\uFEFF' + lines.join('\r\n');   // BOM so Excel opens it as UTF-8
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="pochron-orders-${new Date().toISOString().slice(0, 10)}.csv"`);
  res.send(csv);
});

// GET /api/studio/orders/:id — full order detail.
studioRouter.get('/orders/:id', (req, res) => {
  const order = getOrder(+req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found.' });
  res.json(order);
});

// POST /api/studio/orders/:id/approve — approve & print → CAPTURE payment (§9).
// Optional body { itemIds: [...] } approves only some photos and captures a
// partial amount; the rest stay held.
const ApproveSchema = z.object({ itemIds: z.array(z.number()).optional(), actualShipping: z.number().nonnegative().optional() });
studioRouter.post('/orders/:id/approve', async (req, res) => {
  const order = getOrder(+req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found.' });
  const ap = ApproveSchema.safeParse(req.body || {});
  if (!ap.success) return res.status(400).json({ error: 'Invalid approval request.', details: ap.error.flatten() });
  const { itemIds, actualShipping } = ap.data;

  const approving = itemIds?.length ? order.items.filter((i) => itemIds.includes(i.id)) : order.items;
  if (!approving.length) return res.status(400).json({ error: 'No matching items to approve.' });

  // Amount to capture: approved line totals on partials; on full approval the
  // order total, minus any down-only shipping correction Julie enters (the real
  // international postage). captureAmountFor keeps this testable.
  const { amount: captureAmount, partial, adjustedShipping } = captureAmountFor(
    { total: order.total, shippingCost: order.shipping_cost, items: order.items },
    { itemIds, actualShipping },
  );

  // A lapsed authorization cannot be captured. Say so plainly and point at the
  // fix, rather than letting Stripe return an opaque error.
  const win = authWindow(order);
  if (win.status === 'expired') {
    return res.status(409).json({
      error: 'The card authorization for this order has expired. Send the customer a re-authorization request, then approve once they confirm.',
      code: 'AUTH_EXPIRED',
      auth: win,
    });
  }

  // An order authorized under a different payment driver can't be captured here
  // (e.g. a mock ref left over from testing, now that Stripe is live).
  // Mock references look like `pi_mock_PS-123456_...`, which also start with
  // `pi_` — so test for the mock marker, not just the prefix.
  const ref = String(order.payment_ref || '');
  const isRealStripeRef = /^pi_(?!mock)/.test(ref);
  if (payment.name === 'stripe' && ref && !isRealStripeRef) {
    return res.status(409).json({
      error: 'This order was placed before live payments were enabled, so there is nothing to capture. Place a new test order.',
      code: 'PAYMENT_DRIVER_MISMATCH',
    });
  }

  let cap;
  try {
    cap = await payment.capture({ paymentRef: order.payment_ref, amount: (partial || adjustedShipping != null) ? captureAmount : undefined });
  } catch (e) {
    return res.status(402).json({ error: 'Capture failed. The authorization may have expired — re-authorize the customer.', detail: e.message, code: 'CAPTURE_FAILED' });
  }

  const tx = db.transaction(() => {
    approving.forEach((i) =>
      db.prepare(`UPDATE order_items SET item_status='approved', captured_amount=? WHERE id=?`)
        .run(+(i.line_total).toFixed(2), i.id));
    const remaining = db.prepare(`SELECT COUNT(*) c FROM order_items WHERE order_id=? AND item_status!='approved'`).get(order.id).c;
    if (remaining === 0) {
      if (adjustedShipping != null) db.prepare(`UPDATE orders SET shipping_cost=?, total=? WHERE id=?`).run(adjustedShipping, captureAmount, order.id);
      db.prepare(`UPDATE orders SET payment_status='captured', updated_at=datetime('now') WHERE id=?`).run(order.id);
      transition(order.id, 'approved', `Approved; captured ${cap.capturedAmount ?? captureAmount}${adjustedShipping != null ? ` (shipping set to $${adjustedShipping})` : ''}`);
      db.prepare(`UPDATE orders SET status='in_production' WHERE id=?`).run(order.id);
    } else {
      db.prepare(`UPDATE orders SET payment_status='partially_captured' WHERE id=?`).run(order.id);
      transition(order.id, 'on_hold', `Partial approval; ${remaining} item(s) still held`);
    }
  });
  tx();

  // For each approved self-edit, generate the print-ready file from the original
  // + recipe (§6). Failures here don't undo the capture — they surface as a note.
  const rendered = [];
  for (const i of approving) {
    try { const r = await renderPrintFile(i); if (r) rendered.push(r); }
    catch (e) { addMessage(order.id, 'system', `Print render failed for item ${i.id}: ${e.message}`); }
  }

  const fresh = getOrder(order.id);
  try { if (fresh.status === 'in_production' || fresh.status === 'approved') await emails.approved(fresh, cap.capturedAmount ?? captureAmount); }
  catch (e) { console.error('Approved email failed:', e.message); }

  res.json({ ref: order.ref, status: getOrder(order.id).status, captured: cap.capturedAmount ?? captureAmount, partial, printFiles: rendered });
});

// POST /api/studio/orders/:id/items/:itemId/render — (re)generate a self-edit's
// print-ready file on demand, e.g. to preview the rendered result before approving.
studioRouter.post('/orders/:id/items/:itemId/render', async (req, res) => {
  const order = getOrder(+req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found.' });
  const item = order.items.find((i) => i.id === +req.params.itemId);
  if (!item) return res.status(404).json({ error: 'Item not found.' });
  if (item.color_path !== 'self')
    return res.json({ itemId: item.id, printUrl: item.originalUrl, note: 'Prints directly from the original (no self-edit recipe).' });
  try {
    const r = await renderPrintFile(item);
    if (!r) return res.json({ itemId: item.id, note: 'Recipe is empty — prints from the original.' });
    res.json(r);
  } catch (e) {
    res.status(500).json({ error: 'Render failed.', detail: e.message });
  }
});

// POST /api/studio/orders/:id/hold — message the customer, move to on_hold (§6).
const HoldSchema = z.object({ message: z.string().min(1) });
studioRouter.post('/orders/:id/hold', async (req, res) => {
  const order = getOrder(+req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found.' });
  const parsed = HoldSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Write a message for the customer before placing the order on hold.' });
  const { message } = parsed.data;

  addMessage(order.id, 'studio_to_customer', message);
  transition(order.id, 'on_hold', 'Studio messaged customer');
  try { await emails.hold(order, message); } catch (e) { console.error('Hold email failed:', e.message); }
  res.json({ ref: order.ref, status: 'on_hold' });
});

// POST /api/studio/orders/:id/ship — mark shipped with tracking, notify.
const ShipSchema = z.object({ tracking: z.string().optional() });
studioRouter.post('/orders/:id/ship', async (req, res) => {
  const order = getOrder(+req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found.' });
  const sp = ShipSchema.safeParse(req.body || {});
  if (!sp.success) return res.status(400).json({ error: 'Invalid ship request.', details: sp.error.flatten() });
  const { tracking } = sp.data;
  db.prepare(`UPDATE orders SET tracking=?, updated_at=datetime('now') WHERE id=?`).run(tracking || null, order.id);
  transition(order.id, 'shipped', tracking ? `Shipped: ${tracking}` : 'Shipped');
  try { await emails.shipped(getOrder(order.id), tracking); } catch (e) { console.error('Shipped email failed:', e.message); }
  res.json({ ref: order.ref, status: 'shipped', tracking: tracking || null });
});

// POST /api/studio/orders/:id/cancel — release the hold on an order that hasn't
// been charged yet (instead of waiting ~7 days for it to lapse). Notifies the
// customer. Refuse if it's already been charged — that path is /refund.
studioRouter.post('/orders/:id/cancel', async (req, res) => {
  const order = getOrder(+req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found.' });
  if (['captured', 'partially_captured'].includes(order.payment_status)) {
    return res.status(409).json({ error: 'This order has already been charged — use Refund instead.', code: 'ALREADY_CAPTURED' });
  }
  if (['voided', 'refunded'].includes(order.payment_status) || order.status === 'cancelled') {
    return res.status(409).json({ error: 'This order is already cancelled.', code: 'ALREADY_CANCELLED' });
  }
  // Best-effort: the hold may already have lapsed, which is fine — still cancel.
  if (order.payment_ref) {
    try { await payment.void({ paymentRef: order.payment_ref }); }
    catch (e) { console.warn('Cancel: void failed (hold may have lapsed):', e.message); }
  }
  db.prepare(`UPDATE orders SET payment_status='voided' WHERE id=?`).run(order.id);
  transition(order.id, 'cancelled', 'Order cancelled; card hold released');
  try { await emails.cancelled(getOrder(order.id)); } catch (e) { console.error('Cancelled email failed:', e.message); }
  res.json({ ok: true, ref: order.ref, status: 'cancelled' });
});

// POST /api/studio/orders/:id/refund — refund a charged order in full via the
// payment processor. Refuse if nothing was charged (use /cancel) or already refunded.
studioRouter.post('/orders/:id/refund', async (req, res) => {
  const order = getOrder(+req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found.' });
  if (!['captured', 'partially_captured'].includes(order.payment_status)) {
    return res.status(409).json({ error: 'This order has not been charged, so there is nothing to refund. Use Cancel to release the hold.', code: 'NOT_CAPTURED' });
  }
  if (order.payment_status === 'refunded') {
    return res.status(409).json({ error: 'This order has already been refunded.', code: 'ALREADY_REFUNDED' });
  }
  let refund;
  try { refund = await payment.refund({ paymentRef: order.payment_ref }); }
  catch (e) { return res.status(402).json({ error: 'Refund failed at the payment processor.', detail: e.message, code: 'REFUND_FAILED' }); }
  db.prepare(`UPDATE orders SET payment_status='refunded' WHERE id=?`).run(order.id);
  const amount = refund.amount ?? order.total;
  transition(order.id, 'cancelled', `Refunded $${Number(amount).toFixed(2)}`);
  try { await emails.refunded(getOrder(order.id), amount); } catch (e) { console.error('Refund email failed:', e.message); }
  res.json({ ok: true, ref: order.ref, status: 'cancelled', refunded: amount });
});

// POST /api/studio/orders/:id/reauthorize — the authorization has lapsed (or is
// about to). Void whatever is left of the old hold, open a fresh one for the
// current total, and email the customer a link to re-confirm their card.
//
// The customer has to act because we do not store card details — which is the
// point. Re-confirming is one click on a saved card, and it keeps the studio's
// promise intact: still nothing captured until approval.
studioRouter.post('/orders/:id/reauthorize', async (req, res) => {
  const order = getOrder(+req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found.' });
  if (['captured', 'partially_captured'].includes(order.payment_status)) {
    return res.status(409).json({ error: 'This order has already been charged.', code: 'ALREADY_CAPTURED' });
  }

  // Release the stale hold so the customer is not double-reserved.
  if (order.payment_ref) {
    try { await payment.void({ paymentRef: order.payment_ref }); }
    catch (e) { console.warn('Re-auth: releasing the old hold failed (it may have lapsed already):', e.message); }
  }

  let auth;
  try {
    auth = await payment.authorize({
      amount: order.total, email: order.email, orderRef: order.ref,
    });
  } catch (e) {
    return res.status(502).json({ error: 'Could not open a new authorization.', detail: e.message });
  }

  db.prepare(
    `UPDATE orders SET payment_ref=?, payment_status='reauth_pending',
       authorized_at=datetime('now'), reauth_count=COALESCE(reauth_count,0)+1 WHERE id=?`
  ).run(auth.paymentRef, order.id);

  transition(order.id, 'on_hold', 'Authorization expired; re-authorization requested');
  addMessage(order.id, 'system', `Re-authorization requested (attempt ${(order.reauth_count || 0) + 1}).`);

  const fresh = getOrder(order.id);
  try { await emails.reauthorize(fresh, auth.clientSecret); }
  catch (e) { console.error('Re-auth email failed:', e.message); }

  res.json({
    ref: order.ref,
    status: 'reauth_pending',
    paymentRef: auth.paymentRef,
    note: 'Customer emailed a link to re-confirm their card. Approve once they have.',
  });
});
